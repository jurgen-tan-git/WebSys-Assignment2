<?php 
    session_start();
    session_destroy();
    header("Location: index.php");
    exit;
    
?>
<img src="images/black.jpg"  width="500" height="100">